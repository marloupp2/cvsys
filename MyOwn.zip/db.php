<?php
mysql_connect("localhost","root","");
mysql_select_db("cpsu_voting_system");
?>