
<!-- Sales stats -->
      <div class="card collapse-icon accordion-icon-rotate">
        <div class="card-header bg-danger">
          <h1 class="card-title pl-1  white">FLP Candidates</h1>
        </div>
        <div class="card-content">
          <div class="card-body">
            <div class="accordion" id="cardAccordion" data-toggle-hover="true">



              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">President</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapseOne" class="pt-1 pb-1 collapse" aria-labelledby="headingOne" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp1"></div>
                                    



                   
                  </div>
                </div>
              </div>


              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="headingTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Vice President</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapseTwo" class="pt-1 pb-1 collapse" aria-labelledby="headingTwo" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp2"></div>
                                    



                   
                  </div>
                </div>
              </div>


              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="headingTwo3" data-toggle="collapse" data-target="#collapseTwo3" aria-expanded="false" aria-controls="collapseTwo3" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Secretary</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapseTwo3" class="pt-1 pb-1 collapse" aria-labelledby="headingTwo3" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp3"></div>
                                    



                   
                  </div>
                </div>
              </div>




             <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading4" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Treasurer</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse4" class="pt-1 pb-1 collapse" aria-labelledby="heading4" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp4"></div>
                                    



                   
                  </div>
                </div>
              </div>




             <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading5" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapse5" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Auditor</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse5" class="pt-1 pb-1 collapse" aria-labelledby="heading5" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp5"></div>
                                    



                   
                  </div>
                </div>
              </div>



              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading6" data-toggle="collapse" data-target="#collapse6" aria-expanded="false" aria-controls="collapse6" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">PIO</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse6" class="pt-1 pb-1 collapse" aria-labelledby="heading6" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp6"></div>
                                    



                   
                  </div>
                </div>
              </div>



              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading7" data-toggle="collapse" data-target="#collapse7" aria-expanded="false" aria-controls="collapse7" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Business Manager</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse7" class="pt-1 pb-1 collapse" aria-labelledby="heading7" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp7"></div>
                                    



                   
                  </div>
                </div>
              </div>



                            <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading9" data-toggle="collapse" data-target="#collapse9" aria-expanded="false" aria-controls="collapse9" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Muse</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse9" class="pt-1 pb-1 collapse" aria-labelledby="heading9" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp9"></div>
                                    



                   
                  </div>
                </div>
              </div>





              <div class="card" style="margin-bottom: 0px;">
                <div class="card-header collapsed" id="heading8" data-toggle="collapse" data-target="#collapse8" aria-expanded="false" aria-controls="collapse8" role="button">
                  <span class="collapsed collapse-title h3 font-weight-bold">Sentinel</span>
                  <span style="float: right;"><b><i class="fas fa-chevron-down"></i></b></span>
                </div>
                <div id="collapse8" class="pt-1 pb-1 collapse" aria-labelledby="heading8" data-parent="#cardAccordion" style="">
                  <div class="card-body container">
                    




       <div id="viewpresidentflp8"></div>
                                    



                   
                  </div>
                </div>
              </div>








            </div>
          </div>
        </div>
      </div>


 
      <script>
        $(document).ready(function(){
          setInterval(function(){

          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit1":1,
          },
          success :function(viewpresidentflp1){
            $("#viewpresidentflp1").html(viewpresidentflp1);
          }
          })

          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit2":1,
          },
          success :function(viewpresidentflp2){
            $("#viewpresidentflp2").html(viewpresidentflp2);
          }
          })

          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit3":1,
          },
          success :function(viewpresidentflp3){
            $("#viewpresidentflp3").html(viewpresidentflp3);
          }
          })

           $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit4":1,
          },
          success :function(viewpresidentflp4){
            $("#viewpresidentflp4").html(viewpresidentflp4);
          }
          })


         $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit5":1,
          },
          success :function(viewpresidentflp5){
            $("#viewpresidentflp5").html(viewpresidentflp5);
          }
          })


          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit6":1,
          },
          success :function(viewpresidentflp6){
            $("#viewpresidentflp6").html(viewpresidentflp6);
          }
          })


          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit7":1,
          },
          success :function(viewpresidentflp7){
            $("#viewpresidentflp7").html(viewpresidentflp7);
          }
          })



          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit8":1,
          },
          success :function(viewpresidentflp8){
            $("#viewpresidentflp8").html(viewpresidentflp8);
          }
          })


          $.ajax({
          url:"process/flpcandidate.php",
          type:"POST",
          data:{
            "submit9":1,
          },
          success :function(viewpresidentflp9){
            $("#viewpresidentflp9").html(viewpresidentflp9);
          }
          })



          },1000);
        });


      </script>