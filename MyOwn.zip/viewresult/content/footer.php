<script type="text/javascript" src="../../js/mdb.js"></script>
<!-- SCRIPTS -->

    <script type="text/javascript" src="../../Material Design Bootstrap Template_files/mdb.js"></script>
    <!-- JQuery -->

    <script type="text/javascript" src="../../Material Design Bootstrap Template_files/jquery-3.3.1.min.js.download"></script>

    <!-- Tooltips -->
    <script type="text/javascript" src="../../Material Design Bootstrap Template_files/popper.min.js.download"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../../Material Design Bootstrap Template_files/bootstrap.min.js.download"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="../../Material Design Bootstrap Template_files/mdb.min.js.download"></script>
    <script type="text/javascript" src="../../bootstrap/js/addons/datatables.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../../queryupload/Material Design Bootstrap_files/mdb.min.js.download"></script><div class="hiddendiv common"></div>
  
  <script>
      $(document).ready(function () {
$('#dtHorizontalVerticalExample').DataTable({
"scrollX": true,
"scrollY": 330,
});
$('.dataTables_length').addClass('bs-select');
});

$(document).ready(function () {
$('#dtHorizontalVerticalExample2').DataTable({
"scrollX": true,
"scrollY": 330,
});
$('.dataTables_length').addClass('bs-select');
});

$(document).ready(function () {
$('#dtHorizontalVerticalExample3').DataTable({
"scrollX": true,
"scrollY": 330,
});
$('.dataTables_length').addClass('bs-select');
});
  </script>