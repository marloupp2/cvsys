
<style>
	iframe{
		width: auto;
    width: 100%;
	}
</style>


<!-- Modal -->
<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <iframe  width="400" height="440" src="./datepicker/bootstrap-datetimepicker-master/dateandtime/index.html"></iframe>
    </div>
  </div>
</div>