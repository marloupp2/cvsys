<?php
if (isset($_POST['submit'])) {
	echo date('F d, Y h:i:sA');
}
?>